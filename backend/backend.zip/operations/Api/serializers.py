import json

from django.db import transaction
from django.utils import timezone
from rest_framework import serializers

from accounts.Api.v1.serializer import UserDetailSerializer
from accounts.models import Staff, User
from operations.models import (
    Assignment,
    AssignmentMedia,
    AssignmentRecipient,
    AssignmentSubmission,
    Content,
    ContentRecipient,
    Conversation,
    ConversationParticipant,
    Feature,
    Line,
    LineMember,
    Media,
    Message,
    StaffLine,
    SubmissionMedia, Form, ConsultationForm, SubmitConsultationForm,Appointment,
)





def create_recipient_conversation(content, member):
    """ساخت ContentRecipient همراه با Conversation (همان الگوی تکلیف)."""
    conversation = Conversation.objects.create(line=content.line)

    ConversationParticipant.objects.create(
        conversation=conversation,
        user=member.user,
    )
    for staff_line in content.line.staff_memberships.select_related("staff__user"):
        ConversationParticipant.objects.get_or_create(
            conversation=conversation,
            user=staff_line.staff.user,
        )

    return ContentRecipient.objects.create(
        content=content,
        member=member,
        conversation=conversation,
    )


class MediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Media
        fields = (
            "id",
            "text",
            "file",
        )


class FeatureSerializer(serializers.ModelSerializer):
    media = MediaSerializer(read_only=True)

    class Meta:
        model = Feature
        fields = (
            "id",
            "title",
            "text",
            "media",
            "parent",
        )



class LineChildSerializer(serializers.ModelSerializer):
    features = FeatureSerializer(
        many=True,
        read_only=True,
    )

    class Meta:
        model = Line
        fields = (
            "id",
            "title",
            "descriptions",
            "parent",
            "features",
            "is_required_content",
            "is_required_assignment",
            "is_required_form",
        )



class LineListSerializer(serializers.ModelSerializer):
    children = LineChildSerializer(
        many=True,
        read_only=True,
    )

    class Meta:
        model = Line
        fields = (
            "id",
            "title",
            "descriptions",
            "parent",
            "children",
            "is_required_content",
            "is_required_assignment",
            "is_required_form",
            "is_required_appointment"
        )


class LineDetailSerializer(serializers.ModelSerializer):
    features = FeatureSerializer(
        many=True,
        read_only=True,
    )

    children = LineChildSerializer(
        many=True,
        read_only=True,
    )

    class Meta:
        model = Line
        fields = (
            "id",
            "title",
            "descriptions",
            "parent",
            "features",
            "children",
            "is_required_content",
            "is_required_assignment",
            "is_required_form",
            "is_required_appointment"
        )


class LineMemberSerializer(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)

    class Meta:
        model = LineMember
        fields = (
            "id",
            "user",
        )


class AddLineMembersSerializer(serializers.Serializer):
    user_ids = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(),
        many=True,
        write_only=True,
    )

    def validate(self, attrs):
        line = self.context["lines"]
        users = attrs["user_ids"]

        existing_user_ids = set(
            LineMember.objects.filter(
                line=line,
                user__in=users,
            ).values_list("user_id", flat=True)
        )

        if existing_user_ids:
            raise serializers.ValidationError(
                {"user_ids": ("Some users are already members of this lines.")}
            )

        return attrs

    def create(self, validated_data):
        line = self.context["lines"]
        users = validated_data["user_ids"]

        memberships = [
            LineMember(
                line=line,
                user=user,
            )
            for user in users
        ]

        return LineMember.objects.bulk_create(memberships)


class RemoveLineMembersSerializer(serializers.Serializer):
    user_ids = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(),
        many=True,
        write_only=True,
    )

    def validate(self, attrs):
        line = self.context["lines"]
        users = attrs["user_ids"]

        existing_user_ids = set(
            LineMember.objects.filter(
                line=line,
                user__in=users,
            ).values_list("user_id", flat=True)
        )

        requested_user_ids = {user.id for user in users}

        not_members = requested_user_ids - existing_user_ids

        if not_members:
            raise serializers.ValidationError(
                {
                    "user_ids": (
                        f"These users are not members of this lines: "
                        f"{sorted(not_members)}"
                    )
                }
            )

        return attrs

class StaffLineSerializer(serializers.ModelSerializer):
    staff = serializers.StringRelatedField()
    staff_id = serializers.UUIDField(source="staff.id", read_only=True)

    user = UserDetailSerializer(source="staff.user", read_only=True)

    employee_code = serializers.CharField(
        source="staff.employee_code",
        read_only=True
    )
    hire_date = serializers.DateField(
        source="staff.hire_date",
        read_only=True
    )
    position = serializers.CharField(
        source="staff.position",
        read_only=True
    )

    class Meta:
        model = StaffLine
        fields = (
            "id",
            "staff",
            "staff_id",
            "user",
            "employee_code",
            "hire_date",
            "position",
        )

class AddLineStaffSerializer(serializers.Serializer):
    staff_ids = serializers.PrimaryKeyRelatedField(
        queryset=Staff.objects.all(),
        many=True,
        write_only=True,
    )

    def validate(self, attrs):
        line = self.context["lines"]
        staff_members = attrs["staff_ids"]

        existing_ids = set(
            StaffLine.objects.filter(
                line=line,
                staff__in=staff_members,
            ).values_list("staff_id", flat=True)
        )

        if existing_ids:
            raise serializers.ValidationError(
                {
                    "staff_ids": (
                        "Some staff members are already assigned to this lines."
                    )
                }
            )

        return attrs

    def create(self, validated_data):
        line = self.context["lines"]
        staff_members = validated_data["staff_ids"]

        staff_lines = [
            StaffLine(
                line=line,
                staff=staff,
            )
            for staff in staff_members
        ]

        return StaffLine.objects.bulk_create(staff_lines)


class RemoveLineStaffSerializer(serializers.Serializer):
    staff_ids = serializers.PrimaryKeyRelatedField(
        queryset=Staff.objects.all(),
        many=True,
        write_only=True,
    )

    def validate(self, attrs):
        line = self.context["lines"]
        staff_members = attrs["staff_ids"]

        requested_ids = {staff.id for staff in staff_members}

        existing_ids = set(
            StaffLine.objects.filter(
                line=line,
                staff__in=staff_members,
            ).values_list("staff_id", flat=True)
        )

        not_members = requested_ids - existing_ids

        if not_members:
            raise serializers.ValidationError(
                {
                    "staff_ids": (
                        f"These staff are not assigned to this lines: "
                        f"{sorted(not_members)}"
                    )
                }
            )

        return attrs


class AssignmentMediaSerializer(serializers.ModelSerializer):
    media = MediaSerializer()

    class Meta:
        model = AssignmentMedia
        fields = (
            "id",
            "media",
        )


class AssignmentRecipientSerializer(serializers.ModelSerializer):
    member = LineMemberSerializer()

    class Meta:
        model = AssignmentRecipient
        fields = (
            "id",
            "member",
        )


class MediaItemInputSerializer(serializers.Serializer):
    media = MediaSerializer()


class AssignmentCreateSerializer(serializers.ModelSerializer):
    member_ids = serializers.PrimaryKeyRelatedField(
        source="members",
        queryset=LineMember.objects.select_related("line", "user"),
        many=True,
        write_only=True,
    )

    media_items = MediaItemInputSerializer(
        many=True,
        required=False,
        write_only=True,
    )

    class Meta:
        model = Assignment
        fields = (
            "id",
            "line",
            "title",
            "description",
            "parent",
            "member_ids",
            "media_items",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        line = attrs["line"]
        members = attrs.get("members", [])

        request = self.context["request"]
        user = request.user

        is_admin = (
            user.is_superuser
            or user.user_roles.filter(role__name="admin").exists()
        )

        if not is_admin:
            staff = getattr(user, "staff", None)

            if staff is None:
                raise serializers.ValidationError({"line": "شما Staff نیستید."})

            if not StaffLine.objects.filter(staff=staff, line=line).exists():
                raise serializers.ValidationError(
                    {"line": "شما به این Line دسترسی ندارید."}
                )

        invalid_members = [member.id for member in members if member.line_id != line.id]

        if invalid_members:
            raise serializers.ValidationError(
                {"member_ids": ("تمام اعضای انتخاب‌شده باید عضو همین Line باشند.")}
            )

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        media_items_data = validated_data.pop("media_items", [])
        members = validated_data.pop("members", [])

        assignment = Assignment.objects.create(
            created_by=self.context["request"].user,
            **validated_data,
        )

        for item in media_items_data:
            media_data = item.get("media", {})
            media = Media.objects.create(**media_data)
            AssignmentMedia.objects.create(assignment=assignment, media=media)

        AssignmentRecipient.objects.bulk_create([
            AssignmentRecipient(assignment=assignment, member=member)
            for member in members
        ])

        return assignment


class AssignmentUpdateSerializer(serializers.ModelSerializer):
    member_ids = serializers.PrimaryKeyRelatedField(
        source="members",
        queryset=LineMember.objects.select_related("line", "user"),
        many=True,
        write_only=True,
        required=False,
    )

    media_items = MediaItemInputSerializer(
        many=True,
        required=False,
        write_only=True,
    )

    # Mediaهایی که باید بمانند؛ بقیه‌ی Mediaهای قدیمی حذف می‌شوند
    existing_media_ids = serializers.PrimaryKeyRelatedField(
        queryset=Media.objects.all(),
        many=True,
        write_only=True,
        required=False,
    )

    class Meta:
        model = Assignment
        fields = (
            "id",
            "line",
            "title",
            "description",
            "parent",
            "member_ids",
            "media_items",
            "existing_media_ids",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        user = self.context["request"].user
        line = self.instance.line

        # تغییر line مجاز نیست (گیرنده‌ها و submissionها به line وابسته‌اند)
        new_line = attrs.get("line")
        if new_line is not None and new_line.id != line.id:
            raise serializers.ValidationError(
                {"line": "تغییر Line یک تکلیف مجاز نیست."}
            )

        is_admin = user.is_superuser or user.user_roles.filter(role__name="admin").exists()
        if not is_admin:
            staff = getattr(user, "staff", None)
            if staff is None or not StaffLine.objects.filter(staff=staff, line=line).exists():
                raise serializers.ValidationError(
                    {"line": "شما به این Line دسترسی ندارید."}
                )

        members = attrs.get("members")
        if members is not None:
            if any(m.line_id != line.id for m in members):
                raise serializers.ValidationError(
                    {"member_ids": "تمام اعضای انتخاب‌شده باید عضو همین Line باشند."}
                )

        kept = attrs.get("existing_media_ids")
        if kept is not None:
            own = set(
                AssignmentMedia.objects.filter(assignment=self.instance)
                .values_list("media_id", flat=True)
            )
            if any(m.id not in own for m in kept):
                raise serializers.ValidationError(
                    {"existing_media_ids": "برخی فایل‌ها متعلق به این تکلیف نیستند."}
                )

        return attrs

    @transaction.atomic
    def update(self, instance, validated_data):
        members = validated_data.pop("members", None)
        media_items_data = validated_data.pop("media_items", None)
        kept_media = validated_data.pop("existing_media_ids", None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # ── Recipients: فقط تفاوت‌ها ──
        if members is not None:
            new_ids = {m.id for m in members}
            existing = {
                r.member_id: r
                for r in AssignmentRecipient.objects.filter(assignment=instance)
            }

            removed = [r.id for mid, r in existing.items() if mid not in new_ids]
            if removed:
                AssignmentRecipient.objects.filter(id__in=removed).delete()

            AssignmentRecipient.objects.bulk_create([
                AssignmentRecipient(assignment=instance, member=m)
                for m in members
                if m.id not in existing
            ])

        # ── Media قدیمی که نباید بماند ──
        if kept_media is not None:
            kept_ids = {m.id for m in kept_media}
            stale = AssignmentMedia.objects.filter(assignment=instance).exclude(
                media_id__in=kept_ids
            )
            stale_media_ids = list(stale.values_list("media_id", flat=True))
            stale.delete()
            Media.objects.filter(id__in=stale_media_ids).delete()

        # ── Media جدید ──
        for item in media_items_data or []:
            media = Media.objects.create(**item.get("media", {}))
            AssignmentMedia.objects.create(assignment=instance, media=media)

        return instance

class AllAssignmentListSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()
    line_id = serializers.PrimaryKeyRelatedField(source="line", read_only=True)

    class Meta:
        model = Assignment
        fields = (
            "id",
            "line",
            "line_id",
            "title",
            "description",
            "parent",
        )


class StaffAllAssignmentListSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()
    line_id = serializers.PrimaryKeyRelatedField(source="line", read_only=True)

    class Meta:
        model = Assignment
        fields = (
            "id",
            "line",
            "line_id",
            "title",
            "description",
            "parent",
            "created_at",
        )

class AssignmentListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Assignment
        fields = (
            "id",
            "title",
            "description",
            "parent",
            "created_at",
        )


class AssignmentDetailSerializer(serializers.ModelSerializer):
    media_items = AssignmentMediaSerializer(
        many=True,
        read_only=True,
    )

    recipients = AssignmentRecipientSerializer(
        many=True,
        read_only=True,
    )

    children = AssignmentListSerializer(
        many=True,
        read_only=True,
    )

    class Meta:
        model = Assignment
        fields = (
            "id",
            "line",
            "title",
            "description",
            "parent",
            "media_items",
            "recipients",
            "children",
            "created_at",
            "updated_at",
        )


class AssignmentSubmissionCreateSerializer(serializers.ModelSerializer):
    media_items = MediaSerializer(
        many=True,
        required=False,
        write_only=True,
    )

    class Meta:
        model = AssignmentSubmission
        fields = (
            "assignment_recipient",
            "media_items",
        )
        read_only_fields = ("assignment_recipient",)

    @transaction.atomic
    def create(self, validated_data):
        media_items_data = validated_data.pop("media_items", [])
        
        # ۱. ساخت Submission
        submission = AssignmentSubmission.objects.create(**validated_data)

        # ۲. ساخت Mediaها و ارتباط آن‌ها با Submission
        submission_media_objects = []
        for media_data in media_items_data:
            media = Media.objects.create(**media_data)
            submission_media_objects.append(
                SubmissionMedia(
                    submission=submission,
                    media=media,
                )
            )
        SubmissionMedia.objects.bulk_create(submission_media_objects)

        # ۳. ساخت خودکار Conversation
        assignment = submission.assignment_recipient.assignment
        member = submission.assignment_recipient.member
        
        # ساخت Conversation با عنوان مشخص (برای ردیابی)
        conversation = Conversation.objects.create(
            line=assignment.line,
        )       

        # ۴. اضافه کردن اعضا به Conversation
        
        # الف) اضافه کردن عضو (Member)
        ConversationParticipant.objects.create(
            conversation=conversation,
            user=member.user
        )

        # ب) اضافه کردن کارمندان متصل به این Line
        staff_memberships = assignment.line.staff_memberships.select_related("staff__user").all()
        for staff_line in staff_memberships:
            ConversationParticipant.objects.get_or_create(
                conversation=conversation,
                user=staff_line.staff.user,
        )

        # ۵. اتصال Conversation به Submission
        submission.conversation = conversation
        submission.save()

        return submission
class AssignmentSubmissionUpdateSerializer(serializers.ModelSerializer):
    media_items = MediaSerializer(
        many=True,
        required=False,
        write_only=True,
    )

    class Meta:
        model = AssignmentSubmission
        fields = ("media_items",)

    @transaction.atomic
    def update(self, instance, validated_data):
        media_items_data = validated_data.pop(
            "media_items",
            None,
        )

        # سایر فیلدها
        for attr, value in validated_data.items():
            setattr(
                instance,
                attr,
                value,
            )

        instance.save()

        if media_items_data is not None:
            # Mediaهای قبلی همین Submission
            old_media_ids = list(
                SubmissionMedia.objects.filter(submission=instance).values_list(
                    "media_id",
                    flat=True,
                )
            )

            # حذف relation
            SubmissionMedia.objects.filter(submission=instance).delete()

            # چون Media اختصاصی Submission است،
            # خود Mediaهای قبلی را هم حذف می‌کنیم
            Media.objects.filter(id__in=old_media_ids).delete()

            # ساخت Mediaهای جدید
            submission_media_objects = []

            for media_data in media_items_data:
                media = Media.objects.create(**media_data)

                submission_media_objects.append(
                    SubmissionMedia(
                        submission=instance,
                        media=media,
                    )
                )

            SubmissionMedia.objects.bulk_create(submission_media_objects)

        return instance


class AssignmentSubmissionListSerializer(serializers.ModelSerializer):
    member = serializers.CharField(
        source="assignment_recipient.member.user",
        read_only=True,
    )

    class Meta:
        model = AssignmentSubmission
        fields = (
            "id",
            "member",
            "created_at",
            "updated_at",
        )


class SubmissionMediaDetailSerializer(serializers.ModelSerializer):
    media = MediaSerializer(read_only=True)

    class Meta:
        model = SubmissionMedia
        fields = (
            "id",
            "media",
        )


class AssignmentSubmissionDetailSerializer(serializers.ModelSerializer):
    member = serializers.CharField(
        source="assignment_recipient.member.user",
        read_only=True,
    )

    assignment = serializers.PrimaryKeyRelatedField(
        source="assignment_recipient.assignment",
        read_only=True,
    )

    media_items = SubmissionMediaDetailSerializer(
        many=True,
        read_only=True,
    )

    class Meta:
        model = AssignmentSubmission
        fields = (
            "id",
            "assignment",
            "member",
            "media_items",
            "conversation",
            "created_at",
            "updated_at",
        )


class AllAssignmentSubmissionListSerializer(serializers.ModelSerializer):
    assignment = serializers.CharField(
        source="assignment_recipient.assignment.title",
        read_only=True,
    )

    member = serializers.StringRelatedField(
        source="assignment_recipient.member.user",
    )

    class Meta:
        model = AssignmentSubmission
        fields = (
            "id",
            "assignment",
            "member",
            "created_at",
            "updated_at",
        )

class AdminAssignmentDetailSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()
    
    media_items = AssignmentMediaSerializer(many=True, read_only=True)
    recipients = AssignmentRecipientSerializer(many=True, read_only=True)
    children = AssignmentListSerializer(many=True, read_only=True)

    class Meta:
        model = Assignment
        fields = (
            "id",
            "line",
            "title",
            "description",
            "parent",
            "media_items",
            "recipients",
            "children",
            "created_at",
            "updated_at",
        )
class MemberConversationCreateSerializer(serializers.ModelSerializer):
    line = serializers.PrimaryKeyRelatedField(
        queryset=Line.objects.all(),
        write_only=True,
    )

    class Meta:
        model = Conversation
        fields = (
            "id",
            "line",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        request = self.context["request"]
        line = attrs["lines"]

        member = LineMember.objects.filter(
            user=request.user,
            line=line,
        ).first()

        if not member:
            raise serializers.ValidationError(
                {"lines": "You are not a member of this lines."}
            )

        attrs["member"] = member

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        request = self.context["request"]

        line = validated_data["lines"]
        member = validated_data["member"]

        conversation, created = Conversation.objects.get_or_create(
            line=line,
            member=member,
        )

        ConversationParticipant.objects.get_or_create(
            conversation=conversation,
            user=member.user,
        )

        return conversation


class StaffConversationCreateSerializer(serializers.ModelSerializer):
    line = serializers.PrimaryKeyRelatedField(
        queryset=Line.objects.all(),
        write_only=True,
    )

    member = serializers.PrimaryKeyRelatedField(
        queryset=LineMember.objects.all(),
        write_only=True,
    )

    class Meta:
        model = Conversation
        fields = (
            "id",
            "line",
            "member",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        request = self.context["request"]

        line = attrs["lines"]
        member = attrs["member"]

        # Staff عضو این Line هست؟
        if not StaffLine.objects.filter(
                staff=request.user.staff,
                line=line,
        ).exists():
            raise serializers.ValidationError(
                {"lines": "You are not a staff member of this lines."}
            )

        # Member عضو همین Line هست؟
        if member.line_id != line.id:
            raise serializers.ValidationError(
                {"member": "Selected member does not belong to this lines."}
            )

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        request = self.context["request"]

        line = validated_data["lines"]
        member = validated_data["member"]

        conversation, created = Conversation.objects.get_or_create(
            line=line,
            member=member,
        )

        # Member
        ConversationParticipant.objects.get_or_create(
            conversation=conversation,
            user=member.user,
        )

        # Staff
        ConversationParticipant.objects.get_or_create(
            conversation=conversation,
            user=request.user,
        )

        return conversation


class ConversationListSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()

    class Meta:
        model = Conversation
        fields = (
            "id",
            "line",
            "created_at",
            "updated_at",
        )


class MessageSerializer(serializers.ModelSerializer):
    sender = serializers.CharField(source="sender.user", read_only=True)
    is_mine = serializers.SerializerMethodField()
    media = MediaSerializer(read_only=True)

    class Meta:
        model = Message
        fields = ("id", "sender", "is_mine", "media", "created_at")

    def get_is_mine(self, obj):
        request = self.context.get("request")
        return bool(request and obj.sender.user_id == request.user.id)


class ConversationDetailSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()

    messages = MessageSerializer(
        many=True,
        read_only=True,
    )

    class Meta:
        model = Conversation
        fields = (
            "id",
            "line",
            "messages",
            "created_at",
            "updated_at",
        )


class ConversationJoinSerializer(serializers.Serializer):
    def save(self, **kwargs):
        request = self.context["request"]
        conversation = self.context["conversation"]

        if not StaffLine.objects.filter(
                staff=request.user.staff,
                line=conversation.line,
        ).exists():
            raise serializers.ValidationError(
                "You are not a staff member of this lines."
            )

        participant, created = ConversationParticipant.objects.get_or_create(
            conversation=conversation,
            user=request.user,
        )

        return participant


class MessageCreateSerializer(serializers.ModelSerializer):
    # ✅ فیلدهای مستقیم (فرانت‌اند این‌ها را می‌فرستد)
    text = serializers.CharField(required=False, allow_blank=True, default="")
    file = serializers.FileField(required=False, allow_null=True, default=None)

    class Meta:
        model = Message
        fields = ("text", "file")

    def validate(self, attrs):
        request = self.context["request"]
        conversation = self.context["conversation"]

        participant = ConversationParticipant.objects.filter(
            conversation=conversation,
            user=request.user,
        ).first()

        if not participant:
            raise serializers.ValidationError(
                "You are not a participant of this conversation."
            )

        # ✅ حداقل یکی از متن یا فایل باید وجود داشته باشد
        text = attrs.get("text", "").strip()
        file = attrs.get("file")

        if not text and not file:
            raise serializers.ValidationError(
                "حداقل یکی از فیلدهای text یا file الزامی است."
            )

        attrs["_participant"] = participant
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        participant = validated_data.pop("_participant")
        text = validated_data.pop("text", "").strip()
        file = validated_data.pop("file", None)

        # ✅ ساخت آبجکت Media از text و file
        media = None
        if text or file:
            media = Media.objects.create(
                text=text if text else "",
                file=file
            )

        return Message.objects.create(
            conversation=participant.conversation,
            sender=participant,
            media=media,
        )


class ContentCreateSerializer(serializers.ModelSerializer):
    member_ids = serializers.PrimaryKeyRelatedField(
        source="members",
        queryset=LineMember.objects.all(),
        many=True,
        write_only=True,
        required=False,
    )

    media = MediaSerializer(
        many=True,
        required=False,
    )

    class Meta:
        model = Content
        fields = (
            "id",
            "line",
            "title",
            "text",
            "media",
            "parent",
            "member_ids",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        request = self.context["request"]
        line = attrs.get("line")
        members = attrs.get("members", [])
        parent = attrs.get("parent")

        if not line:
            raise serializers.ValidationError({"line": "This field is required."})

        staff = getattr(request.user, "staff", None)

        if not staff:
            raise serializers.ValidationError(
                {"line": "Only staff members can create content."}
            )
        if not staff.user.is_superuser:
            if not StaffLine.objects.filter(
                    staff=staff,
                    line=line,
            ).exists():
                raise serializers.ValidationError(
                    {"line": "You are not a staff member of this line."}
                )

        # جدید: parent باید متعلق به همان line باشد
        if parent is not None and parent.line_id != line.id:
            raise serializers.ValidationError(
                {"parent": "Parent content must belong to the same line."}
            )

        invalid_members = [member.id for member in members if member.line_id != line.id]

        if invalid_members:
            raise serializers.ValidationError(
                {"member_ids": ("Selected members must belong to the selected line.")}
            )

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        members = validated_data.pop("members", [])
        media_data = validated_data.pop("media", [])

        content = Content.objects.create(
            **validated_data,
        )

        Media.objects.bulk_create(
            [
                Media(
                    content=content,
                    **media,
                )
                for media in media_data
            ]
        )

        for member in members:
            create_recipient_conversation(content, member)

        return content


class ContentUpdateSerializer(serializers.ModelSerializer):
    member_ids = serializers.PrimaryKeyRelatedField(
        source="members",
        queryset=LineMember.objects.all(),
        many=True,
        write_only=True,
        required=False,
    )

    media = MediaSerializer(
        many=True,
        required=False,
    )

    existing_media_ids = serializers.PrimaryKeyRelatedField(
        queryset=Media.objects.all(),
        many=True,
        write_only=True,
        required=False,
    )

    class Meta:
        model = Content
        fields = (
            "id",
            "line",
            "title",
            "text",
            "media",
            "parent",
            "member_ids",
            "existing_media_ids",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        request = self.context["request"]

        line = attrs.get("line", self.instance.line)
        members = attrs.get("members")

        staff = getattr(request.user, "staff", None)

        if not staff:
            raise serializers.ValidationError(
                {"detail": "Only staff members can update content."}
            )

        if not StaffLine.objects.filter(
                staff=staff,
                line=line,
        ).exists():
            raise serializers.ValidationError(
                {"line": "You are not a staff member of this line."}
            )

        if members is not None:
            invalid_members = [
                member.id for member in members if member.line_id != line.id
            ]

            if invalid_members:
                raise serializers.ValidationError(
                    {
                        "member_ids": (
                            "Selected members must belong to the selected line."
                        )
                    }
                )

        # existing_media_ids باید متعلق به همین content باشند، وگرنه یک
        # کلاینت می‌تواند با فرستادن id یک Media از محتوای دیگر، آن را
        # به این محتوا "بدزدد" (چون existing_media_ids فقط "نگه‌داشتن"
        # را کنترل می‌کند و ownership را از instance موجود جدا می‌کند).
        existing_ids = attrs.get("existing_media_ids")
        if existing_ids is not None:
            foreign = [
                media.id for media in existing_ids
                if media.content_id != self.instance.id
            ]
            if foreign:
                raise serializers.ValidationError(
                    {"existing_media_ids": "Some media do not belong to this content."}
                )

        return attrs

    @transaction.atomic
    def update(self, instance, validated_data):
        print(validated_data)
        members = validated_data.pop("members", None)
        media_data = validated_data.pop("media", None)
        kept_media = validated_data.pop("existing_media_ids", None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # --------------------------------
        # Media: حذف آن‌هایی که در existing_media_ids نیستند (اگر این
        # فیلد اصلاً ارسال شده باشد؛ اگر ارسال نشود یعنی کاری با
        # media های قبلی نداریم)، بعد افزودن media های تازه.
        # --------------------------------
        if kept_media is not None:
            kept_ids = {media.id for media in kept_media}
            instance.media.exclude(id__in=kept_ids).delete()

        if media_data:
            Media.objects.bulk_create([
                Media(content=instance, **media)
                for media in media_data
            ])

        # --------------------------------
        # Recipients
        # --------------------------------
        if members is not None:
            new_ids = {m.id for m in members}
            existing = {
                r.member_id: r
                for r in ContentRecipient.objects.filter(content=instance)
            }

            # حذف گیرنده‌های برداشته‌شده (و گفتگوی آن‌ها)
            for member_id, rec in existing.items():
                if member_id not in new_ids:
                    conv = rec.conversation
                    rec.delete()
                    if conv:
                        conv.delete()

            # افزودن گیرنده‌های جدید
            for member in members:
                if member.id not in existing:
                    create_recipient_conversation(instance, member)

        return instance


class ContentLineListSerializer(serializers.ModelSerializer):
    line = LineListSerializer()

    class Meta:
        model = Content
        fields = (
            "id",
            "line",
            "title",
            "text",
            "parent",
            "created_at",
            "updated_at",
        )


class ContentRecipientSerializer(serializers.ModelSerializer):
    member = LineMemberSerializer(read_only=True)

    class Meta:
        model = ContentRecipient
        fields = ("id", "member", "conversation")


class ContentDetailSerializer(serializers.ModelSerializer):
    line = LineDetailSerializer()

    media = MediaSerializer(read_only=True, many=True)

    recipients = ContentRecipientSerializer(
        many=True,
        read_only=True,
    )

    children = serializers.SerializerMethodField()

    conversation = serializers.SerializerMethodField()

    class Meta:
        model = Content
        fields = (
            "id", "line", "title", "text", "media", "parent",
            "children", "recipients", "conversation",  # ← conversation اضافه شد
            "created_at", "updated_at",
        )

    def get_children(self, obj):
        return ContentLineListSerializer(
            obj.children.all(),
            many=True,
        ).data

    def get_conversation(self, obj):
        request = self.context.get("request")
        if not request:
            return None
        rec = obj.recipients.filter(member__user=request.user).first()
        conv_id = getattr(rec, "conversation_id", None)
        return str(conv_id) if conv_id else None



class ContentListSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()

    class Meta:
        model = Content
        fields = (
            "id",
            "line",
            "title",
            "text",
            "parent",
            "created_at",
            "updated_at",
        )


class MemberContentDetailSerializer(ContentDetailSerializer):
    class Meta(ContentDetailSerializer.Meta):
        fields = tuple(
            f for f in ContentDetailSerializer.Meta.fields
            if f not in ("recipients", "children")
        )

class FormSerializer(serializers.ModelSerializer):
    class Meta:
        model = Form
        fields = ["id", "file"]


class ConsultationFormSerializer(serializers.ModelSerializer):
    forms = FormSerializer(
        source="form",
        many=True,
        read_only=True
    )

    class Meta:
        model = ConsultationForm
        fields = [
            "id",
            "title",
            "description",
            "forms",
        ]


class SubmitConsultationFormSerializer(serializers.ModelSerializer):
    forms = FormSerializer(source="form", many=True, read_only=True)

    class Meta:
        model = SubmitConsultationForm
        # فیلدهای consultation و member را از fields حذف کنید یا read_only بگذارید
        # اگر write_only هستند، باید در create هندل شوند
        fields = ["id", "title", "description", "forms"]

    def create(self, validated_data):
        # گرفتن مقادیر از context که توسط ویو ست شده‌اند
        consultation = self.context.get('consultation')
        member = self.context.get('member')

        if not consultation or not member:
            raise serializers.ValidationError("Context information is missing.")

        # ساخت آبجکت با مقادیر صحیح
        return SubmitConsultationForm.objects.create(
            consultation=consultation,
            member=member,
            **validated_data
        )

# operations/Api/serializers.py

class ConsultationFormCreateUpdateSerializer(serializers.ModelSerializer):
    files = serializers.ListField(
        child=serializers.FileField(),
        write_only=True,
        required=False,
    )
    existing_file_ids = serializers.ListField(
        child=serializers.UUIDField(),  # یا CharField بسته به نوع ID شما
        write_only=True,
        required=False,
    )
    forms = FormSerializer(
        source="form",
        many=True,
        read_only=True,
    )

    class Meta:
        model = ConsultationForm
        fields = ["id", "title", "description", "forms", "files", "existing_file_ids"]
        # خط line را از fields حذف کردیم چون دستی هندل می‌شود

    @transaction.atomic
    def create(self, validated_data):
        files = validated_data.pop("files", [])
        # line از طریق serializer.save(line=line_obj) در validated_data قرار می‌گیرد
        line = validated_data.pop("line", None)

        instance = ConsultationForm.objects.create(
            line=line,
            **validated_data
        )

        if files:
            Form.objects.bulk_create(
                [Form(consultation=instance, file=file) for file in files]
            )
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        files = validated_data.pop("files", None)
        kept_file_ids = validated_data.pop("existing_file_ids", None)

        # آپدیت فیلدهای ساده
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # مدیریت فایل‌های قدیمی
        if kept_file_ids is not None:
            # حذف فایل‌هایی که IDشان در لیست نگهداری نیست
            instance.form.exclude(id__in=kept_file_ids).delete()

        # افزودن فایل‌های جدید
        if files:
            Form.objects.bulk_create([
                Form(consultation=instance, file=file) for file in files
            ])

        return instance


class SubmitConsultationFormCreateUpdateSerializer(serializers.ModelSerializer):
    forms = FormSerializer(
        source="form",
        many=True,
        read_only=True,
    )

    files = serializers.ListField(
        child=serializers.FileField(),
        write_only=True,
        required=False,
    )

    existing_file_ids = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = SubmitConsultationForm
        fields = [
            "id",
            "consultation",
            "member",
            "title",
            "description",
            "forms",
            "files",
            "existing_file_ids",
        ]

        read_only_fields = [
            "id",
            "consultation",
            "member",
            "forms",
        ]

    def validate_existing_file_ids(self, value):
        try:
            ids = json.loads(value)
        except (TypeError, ValueError):
            raise serializers.ValidationError("فرمت existing_file_ids نامعتبر است.")
        if not isinstance(ids, list):
            raise serializers.ValidationError("existing_file_ids باید یک لیست باشد.")
        return ids

    @transaction.atomic
    def create(self, validated_data):
        files = validated_data.pop("files", [])
        # existing_file_ids در create معنایی ندارد (چیزی برای نگه داشتن
        # وجود ندارد چون submission تازه ساخته می‌شود)
        validated_data.pop("existing_file_ids", None)

        consultation = self.context["consultation"]
        member = self.context["member"]

        if SubmitConsultationForm.objects.filter(
                consultation=consultation,
                member=member,
        ).exists():
            raise serializers.ValidationError(
                {"detail": "شما قبلاً برای این فرم Submission ثبت کرده‌اید."}
            )

        instance = SubmitConsultationForm.objects.create(
            consultation=consultation,
            member=member,
            **validated_data,
        )

        if files:
            Form.objects.bulk_create([
                Form(submission=instance, file=file)
                for file in files
            ])

        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        files = validated_data.pop("files", None)
        kept_file_ids = validated_data.pop("existing_file_ids", None)

        validated_data.pop("consultation", None)
        validated_data.pop("member", None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if kept_file_ids is not None:
            instance.form.exclude(id__in=kept_file_ids).delete()

        if files:
            Form.objects.bulk_create([
                Form(submission=instance, file=file)
                for file in files
            ])

        return instance


class SubmitConsultationFormListSerializer(serializers.ModelSerializer):
    forms = FormSerializer(
        source="form",
        many=True,
        read_only=True,
    )

    member_id = serializers.UUIDField(
        source="member.id",
        read_only=True,
    )

    user = UserDetailSerializer(source="member.user", read_only=True)

    class Meta:
        model = SubmitConsultationForm

        fields = [
            "id",
            "member_id",
            "user",
            "title",
            "description",
            "forms",
            "created_at",
        ]

# ───────────────────────────────────────────
# Appointment Serializers
# ───────────────────────────────────────────

class AppointmentListSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()
    member = serializers.StringRelatedField(allow_null=True)
    staff = serializers.SerializerMethodField()
    requested_by = serializers.StringRelatedField(allow_null=True)

    class Meta:
        model = Appointment
        fields = (
            "id",
            "line",
            "member",
            "requested_by",
            "staff",
            "status",
            "description",
            "appointment_time",
            "created_at",
        )

    def get_staff(self, obj):
        if not obj.staff:
            return None

        return f"{obj.staff.user.first_name} {obj.staff.user.last_name} - {obj.staff.employee_code}".strip()


class AppointmentDetailSerializer(serializers.ModelSerializer):
    line = serializers.StringRelatedField()
    member = LineMemberSerializer(read_only=True)
    staff = StaffLineSerializer(read_only=True)
    requested_by = serializers.SerializerMethodField()
    requester_name = serializers.SerializerMethodField()
    staff_name = serializers.SerializerMethodField()

    class Meta:
        model = Appointment
        fields  = (
            "id", "line", "line_id", "member", "requested_by", "requester_name",
            "staff", "staff_name", "status", "description",
            "appointment_time", "created_at", "updated_at",
        )

    @staticmethod
    def _name(user):
        if user is None:
            return None
        return f"{user.first_name} {user.last_name}".strip() or str(user)

    def get_requested_by(self, obj):
        u = obj.requested_by
        return {"id": str(u.pk), "name": self._name(u)} if u else None

    def get_requester_name(self, obj):
        u = obj.requested_by or (obj.member.user if obj.member else None)
        return self._name(u)

    def get_staff_name(self, obj):
        return self._name(obj.staff.user) if obj.staff else None


class MemberAppointmentRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = ("id", "line", "description")
        read_only_fields = ("id",)

    def validate_line(self, value):
        user = self.context["request"].user

        # ۱) اگر کاربر از قبل عضو این لاین است، نیازی به درخواست نیست
        if LineMember.objects.filter(user=user, line=value).exists():
            raise serializers.ValidationError("شما قبلاً عضو این لاین هستید.")

        # ۲) جلوگیری از درخواست تکراری در حال انتظار
        if Appointment.objects.filter(
            requested_by=user, line=value, status=Appointment.Status.PENDING
        ).exists():
            raise serializers.ValidationError("شما قبلاً برای این لاین درخواست فعالی ثبت کرده‌اید.")

        return value

    def create(self, validated_data):
        user = self.context["request"].user
        return Appointment.objects.create(
            requested_by=user,
            member=None,
            status=Appointment.Status.PENDING,
            **validated_data,
        )


class AppointmentCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = (
            "id",
            "line",
            "member",
            "staff",
            "status",
            "appointment_time",
        )
        read_only_fields = ("id",)

    def validate(self, attrs):
        line = attrs["line"]
        member = attrs["member"]
        staff = attrs["staff"]
        appointment_time = attrs["appointment_time"]

        # member باید عضو همین line باشد
        if member.line_id != line.id:
            raise serializers.ValidationError(
                {"member": "این عضو متعلق به این Line نیست."}
            )

        # staff باید عضو همین line باشد
        if not StaffLine.objects.filter(staff=staff, line=line).exists():
            raise serializers.ValidationError(
                {"staff": "این Staff به این Line دسترسی ندارد."}
            )

        # staff در همان زمان appointment دیگری نداشته باشد
        if Appointment.objects.filter(
            staff=staff,
            appointment_time=appointment_time,
        ).exists():
            raise serializers.ValidationError(
                {"appointment_time": "این Staff در این زمان appointment دیگری دارد."}
            )

        return attrs



class AppointmentUpdateSerializer(serializers.ModelSerializer):
    staff = serializers.PrimaryKeyRelatedField(
        queryset=Staff.objects.all(), required=False, allow_null=True
    )

    class Meta:
        model = Appointment
        fields = ("id", "status", "staff", "appointment_time")
        read_only_fields = ("id",)

    def validate(self, attrs):
        instance = self.instance

        # مقدار نهایی بعد از اعمال تغییرات (برای PATCH فیلدهای نفرستاده از instance می‌آیند)
        staff = attrs.get("staff", instance.staff)
        appointment_time = attrs.get("appointment_time", instance.appointment_time)
        new_status = attrs.get("status", instance.status)

        # staff باید عضو همان لاین باشد
        if staff and not StaffLine.objects.filter(staff=staff, line=instance.line).exists():
            raise serializers.ValidationError({"staff": "این Staff عضو این لاین نیست."})

        # زمان نباید در گذشته باشد (فقط وقتی زمان تغییر کرده)
        if "appointment_time" in attrs and appointment_time and appointment_time < timezone.now():
            raise serializers.ValidationError({"appointment_time": "زمان نوبت نمی‌تواند در گذشته باشد."})

        # تأیید فقط با staff و زمان
        if new_status == Appointment.Status.CONFIRMED:
            errors = {}
            if not staff:
                errors["staff"] = "برای تأیید نوبت، تعیین Staff الزامی است."
            if not appointment_time:
                errors["appointment_time"] = "برای تأیید نوبت، تعیین زمان الزامی است."
            if errors:
                raise serializers.ValidationError(errors)

        # تداخل زمانی (فقط وقتی هر دو مقدار موجود باشند)
        if staff and appointment_time:
            conflict = Appointment.objects.filter(
                staff=staff,
                appointment_time=appointment_time,
            ).exclude(
                pk=instance.pk
            ).exclude(
                status=Appointment.Status.CANCELED
            ).exists()

            if conflict:
                raise serializers.ValidationError(
                    {"appointment_time": "این Staff در این زمان نوبت دیگری دارد."}
                )

        return attrs

    def update(self, instance, validated_data):
        # اگر staff و زمان ست شدند و status صریحاً نیامده، خودکار تأیید شود
        staff = validated_data.get("staff", instance.staff)
        appointment_time = validated_data.get("appointment_time", instance.appointment_time)

        if (
            "status" not in validated_data
            and instance.status == Appointment.Status.PENDING
            and staff
            and appointment_time
        ):
            validated_data["status"] = Appointment.Status.CONFIRMED

        if (
                validated_data.get("status") == Appointment.Status.CONFIRMED
                and instance.member is None
                and instance.requested_by
        ):
            member, _ = LineMember.objects.get_or_create(
                user=instance.requested_by, line=instance.line
            )
            validated_data["member"] = member

        return super().update(instance, validated_data)