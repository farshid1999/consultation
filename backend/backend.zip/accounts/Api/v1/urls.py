from django.urls import include, path

from accounts.Api.v1.view import *

# =========================
# Auth URLs
# =========================

auth_urls = [
    path("login/", LoginView.as_view(), name="login"),
    path("register/", RegisterView.as_view(), name="register"),
    path("refresh/", RefreshTokenView.as_view(), name="refresh-token"),
    path("verify/", VerifyTokenView.as_view(), name="verify-token"),
    path("logout/", LogoutView.as_view(), name="logout"),
]

# =========================
# Role URLs
# =========================

role_urls = [
    path("", RoleListAPIView.as_view(), name="role-list"),
    path("create/", RoleCreateAPIView.as_view(), name="role-create"),
    path("<int:pk>/", RoleDetailAPIView.as_view(), name="role-detail"),
    path("<int:pk>/update/", RoleUpdateAPIView.as_view(), name="role-update"),
    path("<int:pk>/delete/", RoleDeleteAPIView.as_view(), name="role-delete"),
    path("get-user-role/", get_user_role, name="get-user-role"),
]

# =========================
# User URLs
# =========================

user_urls = [
    path("", UserListAPIView.as_view(), name="user-list"),
    path("create/", UserCreateAPIView.as_view(), name="user-create"),
    path("<int:pk>/", UserDetailAPIView.as_view(), name="user-detail"),
    path("<int:pk>/update/", UserUpdateAPIView.as_view(), name="user-update"),
    path("<int:pk>/delete/", UserDeleteAPIView.as_view(), name="user-delete"),
    path("me/", CurrentUserAPIView.as_view(), name="current-user"),
    path(
        "<int:pk>/status/",
        UserStatusUpdateAPIView.as_view(),
        name="user-status-update",
    ),
]

# =========================
# Staff URLs
# =========================

staff_urls = [
    path("", StaffListAPIView.as_view(), name="staff-list"),
    path("create/", StaffCreateAPIView.as_view(), name="staff-create"),
    path("<str:pk>/", StaffDetailAPIView.as_view(), name="staff-detail"),
    path("<str:pk>/update/", StaffUpdateAPIView.as_view(), name="staff-update"),
    path("<str:pk>/delete/", StaffDeleteAPIView.as_view(), name="staff-delete"),
    path(
        "profile/",
        StaffProfileView.as_view(),
        name="staff-profile"
    ),
]

public_staff_urls = [
    path("", PublicStaffListAPIView.as_view(), name="public-staff-list"),
    path("<uuid:pk>/", PublicStaffDetailAPIView.as_view(), name="public-staff-detail"),
]

# =========================
# Main URL List
# =========================
urlpatterns = [
    path("auth/", include(auth_urls)),
    path("roles/", include(role_urls)),
    path("users/", include(user_urls)),
    path("staff/", include(staff_urls)),
    path("public/staff/", include(public_staff_urls)),
]
