import random
from datetime import timedelta

from django.contrib.auth.hashers import check_password, make_password
from django.db import transaction
from rest_framework import serializers

from accounts.models import (
    Address,
    Club,
    Information,
    OTPCode,
    Role,
    Staff,
    User,
    UserRole, Referral,
)
from message.tasks import *

from django.utils import timezone
from django.core.cache import cache

class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = (
            "id",
            "name",
            "description",
        )


class RoleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = (
            "id",
            "name",
            "description",
        )


class RoleUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = (
            "id",
            "name",
            "description",
        )

        read_only_fields = ("id",)


class StaffAssignRoleSerializer(serializers.Serializer):
    staff_id = serializers.PrimaryKeyRelatedField(
        queryset=Staff.objects.select_related("user")
    )

    roles = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all(), many=True)

    @transaction.atomic
    def create(self, validated_data):
        staff = validated_data["staff_id"]
        roles = validated_data["roles"]

        created = []

        for role in roles:
            user_role, _ = UserRole.objects.get_or_create(user=staff.user, role=role)
            created.append(user_role)

        return created


class StaffRemoveRoleSerializer(serializers.Serializer):
    staff_id = serializers.PrimaryKeyRelatedField(
        queryset=Staff.objects.select_related("user")
    )

    roles = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all(), many=True)

    @transaction.atomic
    def save(self, **kwargs):
        staff = self.validated_data["staff_id"]
        roles = self.validated_data["roles"]

        UserRole.objects.filter(user=staff.user, role__in=roles).delete()

        return staff


class UserRoleSerializer(serializers.ModelSerializer):
    role = RoleSerializer(read_only=True)

    class Meta:
        model = UserRole
        fields = (
            "id",
            "role",
        )


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = [
            "id",
            "country",
            "province",
            "city",
            "street",
            "postal_code",
            "description",
        ]


class InformationSerializer(serializers.ModelSerializer):
    children = serializers.SerializerMethodField()

    class Meta:
        model = Information
        fields = (
            "id",
            "title",
            "text",
            "file",
            "parent",
            "children",
        )

    def get_children(self, obj):
        return InformationSerializer(
            obj.children.all(),
            many=True,
            context=self.context,
        ).data

class InformationCreateSerializer(serializers.ModelSerializer):
    children = serializers.ListField(child=serializers.DictField(), required=False)
    existing_file = serializers.CharField(required=False, allow_null=True, write_only=True)

    class Meta:
        model = Information
        fields = ["title", "text", "file", "children", "existing_file"]

    @transaction.atomic
    def create(self, validated_data):
        children = validated_data.pop("children", [])
        existing_file = validated_data.pop("existing_file", None)

        information = Information.objects.create(**validated_data)

        # فایل جدید ندارد ولی فایل قبلی را می‌خواهیم نگه داریم
        if existing_file and not information.file:
            # آدرس کامل را به مسیر نسبی داخل MEDIA_ROOT تبدیل کن
            from django.conf import settings
            from urllib.parse import urlparse

            path = urlparse(existing_file).path
            media_url = settings.MEDIA_URL  # مثل /media/
            if path.startswith(media_url):
                information.file.name = path[len(media_url):]
                information.save(update_fields=["file"])

        for child in children:
            child_serializer = InformationCreateSerializer(data=child)
            child_serializer.is_valid(raise_exception=True)
            child_information = child_serializer.save()
            child_information.parent = information
            child_information.save()

        return information


class ClubSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = Club
        fields = ["id", "name", "address"]

    def create(self, validated_data):

        address_data = validated_data.pop("address")

        address = Address.objects.create(**address_data)

        return Club.objects.create(address=address, **validated_data)


class UserCreateSerializer(serializers.ModelSerializer):
    address = AddressSerializer(required=False)

    club = ClubSerializer(required=False)

    informations = InformationCreateSerializer(many=True, required=False)

    class Meta:
        model = User

        fields = [
            "id",
            "avatar",
            "username",
            "password",
            "first_name",
            "last_name",
            "email",
            "phone_number",
            "national_id",
            "land_line",
            "is_student",
            "degree",
            "job",
            "sport_discipline",
            "professional_background",
            "referral_code",
            "address",
            "club",
            "avatar",
            "bio",
            "birth_date",
            "informations",
            "coach_name",
            "activity_history",
        ]

        extra_kwargs = {
            "password": {"write_only": True, "required": False},
            "username": {"required": False},
            "national_id": {
                "required": True,
                "allow_null": False,
                "allow_blank": False,
            },
        }

    def validate(self, attrs):
        # اگر نام کاربری/رمز داده نشد، از کد ملی و شماره موبایل ساخته می‌شود
        if not attrs.get("username"):
            username = attrs["national_id"]
            if User.objects.filter(username=username).exists():
                raise serializers.ValidationError(
                    {"national_id": "این کد ملی قبلاً ثبت شده است."}
                )
            attrs["username"] = username

        if not attrs.get("password"):
            attrs["password"] = attrs["phone_number"]

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        print(validated_data)

        address_data = validated_data.pop("address", None)

        club_data = validated_data.pop("club", None)

        informations = validated_data.pop("informations", [])

        password = validated_data.pop("password")

        user = User.objects.create(**validated_data)

        user.set_password(password)

        user.save()

        if address_data:
            address = Address.objects.create(**address_data)

            user.address = address

        if club_data:
            club = ClubSerializer().create(club_data)

            user.club = club

        for info_data in informations:
            information = InformationCreateSerializer().create(info_data)

            user.informations.add(information)

        user.save()

        return user


class UserUpdateSerializer(serializers.ModelSerializer):
    address = AddressSerializer(required=False)

    club = ClubSerializer(required=False)

    informations = InformationCreateSerializer(many=True, required=False)

    class Meta:
        model = User

        fields = [
            "id",
            "avatar",
            "username",
            "password",
            "first_name",
            "last_name",
            "email",
            "phone_number",
            "national_id",
            "land_line",
            "is_student",
            "degree",
            "job",
            "sport_discipline",
            "professional_background",
            "referral_code",
            "address",
            "club",
            "avatar",
            "bio",
            "birth_date",
            "informations",
            "coach_name",
            "activity_history",
        ]

        extra_kwargs = {"password": {"write_only": True, "required": False}}

    @transaction.atomic
    def update(self, instance, validated_data):
        print(validated_data)

        address_data = validated_data.pop("address", None)

        club_data = validated_data.pop("club", None)

        informations = validated_data.pop("informations", None)

        password = validated_data.pop("password", None)

        # update normal fields

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if password:
            instance.set_password(password)

        instance.save()

        # update address

        if address_data:
            if instance.address:
                for attr, value in address_data.items():
                    setattr(instance.address, attr, value)

                instance.address.save()

            else:
                address = Address.objects.create(**address_data)

                instance.address = address

                instance.save()

        # update club

        if club_data:
            club_address = club_data.pop("address", None)

            if instance.club:
                for attr, value in club_data.items():
                    setattr(instance.club, attr, value)

                instance.club.save()

                if club_address:
                    for attr, value in club_address.items():
                        setattr(instance.club.address, attr, value)

                    instance.club.address.save()

            else:
                address = Address.objects.create(**club_address)

                club = Club.objects.create(address=address, **club_data)

                instance.club = club

                instance.save()

        # replace informations

        if informations is not None:
            instance.informations.clear()

            for info_data in informations:
                information = InformationCreateSerializer().create(info_data)

                instance.informations.add(information)

        return instance


class StaffCreateSerializer(serializers.ModelSerializer):
    user = UserCreateSerializer()

    class Meta:
        model = Staff

        fields = ["id", "user", "employee_code", "hire_date", "position","is_show_public"]

    @transaction.atomic
    def create(self, validated_data):
        user_data = validated_data.pop("user")
        user = UserCreateSerializer().create(user_data)
        user.is_staff = True
        return Staff.objects.create(user=user, **validated_data)


class StaffUpdateSerializer(serializers.ModelSerializer):
    # فقط برای خروجی/ورودی خام؛ اعتبارسنجی را خودمان انجام می‌دهیم
    user = serializers.DictField(required=False)

    class Meta:
        model = Staff
        fields = ["id", "user", "employee_code", "hire_date", "position"]

    def validate(self, attrs):

        user_data = attrs.get("user")
        if user_data:
            user_serializer = UserUpdateSerializer(
                instance=self.instance.user,
                data=user_data,
                partial=True,
                context=self.context,
            )
            user_serializer.is_valid(raise_exception=True)
            attrs["_user_serializer"] = user_serializer
        return attrs

    @transaction.atomic
    def update(self, instance, validated_data):
        print(validated_data)

        user_serializer = validated_data.pop("_user_serializer", None)
        validated_data.pop("user", None)

        if user_serializer:
            user_serializer.save()

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance



class ReferredUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            "first_name",
            "last_name",
            "username",
            "national_id",
            "phone_number",
        )

class UserListSerializer(serializers.ModelSerializer):
    club = serializers.CharField(source="club.name", read_only=True)
    address = serializers.SerializerMethodField()
    invited_users = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = (
            "id",
            "is_active",
            "username",
            "first_name",
            "last_name",
            "email",
            "phone_number",
            "national_id",
            "is_student",
            "club",
            "address",
            "avatar",
            "coach_name",
            "activity_history",
            "land_line",
            "bio",
            "birth_date",
            "professional_background",
            "referral_code",
            "invited_users",

        )

    def get_address(self, obj):
        if obj.address:
            return f"{obj.address.country} - {obj.address.city}"
        return None

    def get_invited_users(self, obj):
        referrals = obj.referrals.select_related("referred").all()
        users = [referral.referred for referral in referrals]
        return ReferredUserSerializer(users, many=True).data


class UserDetailSerializer(serializers.ModelSerializer):
    address = AddressSerializer(read_only=True)
    club = ClubSerializer(read_only=True)
    informations = InformationSerializer(many=True, read_only=True)
    invited_users = serializers.SerializerMethodField()

    class Meta:
        model = User
        exclude = (
            "password",
            "groups",
            "user_permissions",
        )

    def get_invited_users(self, obj):
        referrals = obj.referrals.select_related("referred").all()
        users = [referral.referred for referral in referrals]
        return ReferredUserSerializer(users, many=True).data



class UserStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["is_active"]


class StaffListSerializer(serializers.ModelSerializer):
    roles = UserRoleSerializer(
        source="user.user_roles",
        many=True,
        read_only=True,
    )
    user = UserListSerializer(read_only=True)

    class Meta:
        model = Staff
        fields = ("id", "employee_code", "position", "hire_date", "roles", "user")


class StaffDetailSerializer(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)
    roles = UserRoleSerializer(
        source="user.user_roles",
        many=True,
        read_only=True,
    )

    class Meta:
        model = Staff

        fields = ("id", "employee_code", "position", "hire_date", "user", "roles")



class AddressStaffProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ["id", "country", "province", "city", "street", "postal_code", "description"]
        read_only_fields = ["id"]
        extra_kwargs = {
            "postal_code": {"required": False, "allow_null": True, "allow_blank": True},
            "description": {"required": False, "allow_null": True, "allow_blank": True},
        }


class InformationStaffProfileSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)  # تا در validated_data بیاید
    file = serializers.FileField(required=False, allow_null=True)

    class Meta:
        model = Information
        fields = ["id", "title", "text", "file"]
        extra_kwargs = {"text": {"required": False, "allow_blank": True}}


class StaffProfileSerializer(serializers.ModelSerializer):
    SCALAR_FIELDS = ["phone_number", "email", "national_id", "land_line",
                     "degree", "job", "bio", "birth_date"]
    EMPTY_TO_NULL = {"national_id", "birth_date"}  # unique / DateField

    phone_number = serializers.CharField(source="user.phone_number")
    email = serializers.EmailField(source="user.email", required=False, allow_null=True, allow_blank=True)
    national_id = serializers.CharField(source="user.national_id", required=False, allow_null=True, allow_blank=True)
    land_line = serializers.CharField(source="user.land_line", required=False, allow_null=True, allow_blank=True)
    degree = serializers.CharField(source="user.degree", required=False, allow_null=True, allow_blank=True)
    job = serializers.CharField(source="user.job", required=False, allow_null=True, allow_blank=True)
    bio = serializers.CharField(source="user.bio", required=False, allow_null=True, allow_blank=True)
    birth_date = serializers.DateField(source="user.birth_date", required=False, allow_null=True)
    avatar = serializers.ImageField(source="user.avatar", required=False, allow_null=True)

    address = AddressStaffProfileSerializer(source="user.address", required=False, allow_null=True)
    informations = InformationStaffProfileSerializer(source="user.informations", many=True, required=False)

    class Meta:
        model = Staff
        fields = ["phone_number", "email", "national_id", "land_line", "degree", "job",
                  "address", "informations", "avatar", "bio", "birth_date"]

    # ---------- ورودی: پشتیبانی از multipart ----------
    def to_internal_value(self, data):
        if hasattr(data, "getlist"):  # QueryDict => multipart / form
            data = self._parse_multipart(data)
        return super().to_internal_value(data)

    def _parse_multipart(self, data):
        out = {}
        for key in self.SCALAR_FIELDS:
            if key in data:
                value = data.get(key)
                out[key] = None if (value == "" and key in self.EMPTY_TO_NULL) else value

        avatar = data.get("avatar")
        if avatar is not None and hasattr(avatar, "read"):  # فقط اگر فایل واقعی بود
            out["avatar"] = avatar

        try:
            if "address" in data:
                out["address"] = json.loads(data.get("address") or "null")
            if "informations" in data:
                items = json.loads(data.get("informations") or "[]")
                for i, item in enumerate(items):
                    f = data.get(f"info_file_{i}")
                    if f is not None and hasattr(f, "read"):
                        item["file"] = f
                out["informations"] = items
        except (ValueError, TypeError):
            raise serializers.ValidationError({"detail": "فرمت JSON نامعتبر است."})
        return out

    # ---------- نوشتن ----------
    @transaction.atomic
    def update(self, instance, validated_data):
        user_data = validated_data.pop("user", {})
        user = instance.user

        address_data = user_data.pop("address", serializers.empty)
        informations_data = user_data.pop("informations", None)

        for attr, value in user_data.items():
            setattr(user, attr, value)

        if address_data is not serializers.empty:
            if address_data is None:
                user.address = None
            elif user.address_id:
                for k, v in address_data.items():
                    setattr(user.address, k, v)
                user.address.save()
            else:
                user.address = Address.objects.create(**address_data)

        user.save()

        if informations_data is not None:
            self._sync_informations(user, informations_data)
        return instance

    @staticmethod
    def _sync_informations(user, items):
        existing = {i.id: i for i in user.informations.all()}
        keep = set()
        for item in items:
            item = dict(item)
            pk = item.pop("id", None)
            obj = existing.get(pk)
            if obj:
                for k, v in item.items():   # file فقط اگر ارسال شده باشد تغییر می‌کند
                    setattr(obj, k, v)
                obj.save()
            else:
                obj = Information.objects.create(**item)
                user.informations.add(obj)
            keep.add(obj.id)
        for pk, obj in existing.items():
            if pk not in keep:
                obj.delete()


class RegisterSerializer(serializers.ModelSerializer):
    club = ClubSerializer()
    referrer_code = serializers.CharField(
        required=False,
        allow_blank=True,
        write_only=True
    )

    class Meta:
        model = User
        extra_kwargs = {
            "national_id": {
                "required": True,
                "allow_null": False,
                "allow_blank": False,
            }
        }
        fields = (
            "first_name",
            "last_name",
            "email",
            "phone_number",
            "national_id",
            "is_student",
            "degree",
            "job",
            "sport_discipline",
            "coach_name",
            "activity_history",
            "professional_background",
            "club",
            "referrer_code",
        )

    def validate_national_id(self, value):
        if User.objects.filter(national_id=value).exists():
            raise serializers.ValidationError(
                "این کد ملی قبلاً ثبت شده است."
            )

        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError(
                "این کد ملی قبلاً ثبت شده است."
            )

        return value

    def validate_referrer_code(self, value):
        if value and not User.objects.filter(
            referral_code=value
        ).exists():
            raise serializers.ValidationError(
                "کد معرف معتبر نیست."
            )

        return value

    @transaction.atomic
    def create(self, validated_data):
        club_data = validated_data.pop("club")
        referrer_code = validated_data.pop("referrer_code", None)

        address_data = club_data.pop("address")
        address = Address.objects.create(**address_data)

        club = Club.objects.create(
            address=address,
            **club_data
        )

        user = User(**validated_data)
        user.username = user.national_id
        user.club = club
        user.set_password(user.phone_number)
        user.save()

        if referrer_code:
            referrer = User.objects.get(
                referral_code=referrer_code
            )

            Referral.objects.create(
                referrer=referrer,
                referred=user
            )

        return user


from django.contrib.auth import authenticate, get_user_model
from rest_framework import serializers




class PasswordLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        User = get_user_model()

        user = User._default_manager.filter(
            username=attrs["username"]
        ).first()

        # بررسی نام کاربری و رمز عبور
        if user is None or not user.check_password(attrs["password"]):
            raise serializers.ValidationError(
                "نام کاربری یا رمز عبور اشتباه است"
            )

        # بررسی فعال بودن حساب بعد از تأیید رمز
        if not user.is_active:
            raise serializers.ValidationError(
                "حساب شما غیرفعال است با پشتیبانی تماس بگیرید."
            )

        attrs["user"] = user
        return attrs



class SendOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=20)

    def validate_phone_number(self, value):
        if not User.objects.filter(phone_number=value).exists():
            raise serializers.ValidationError("کاربری با این شماره وجود ندارد.")

        cache_key = f"otp:cooldown:{value}"

        if cache.get(cache_key):
            raise serializers.ValidationError(
                "کد تایید قبلاً ارسال شده است. لطفاً دو دقیقه دیگر دوباره تلاش کنید."
            )

        return value

    def save(self, **kwargs):
        phone_number = self.validated_data["phone_number"]

        code = f"{random.randint(100000, 999999)}"

        expires_at = timezone.now() + timedelta(minutes=2)

        OTPCode.objects.filter(
            phone_number=phone_number,
            is_used=False,
        ).update(
            is_used=True,
        )

        OTPCode.objects.create(
            phone_number=phone_number,
            code=make_password(code),
            expires_at=expires_at,
        )

        cache.set(
            f"otp:cooldown:{phone_number}",
            True,
            timeout=120,
        )

        send_bulk_sms.delay(
            mobiles=[phone_number],
            message_text=f"کد تایید شما: {code}",
        )

        return {"phone_number": phone_number}



class VerifyOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=20)
    code = serializers.CharField(max_length=6)

    def validate(self, attrs):
        phone_number = attrs["phone_number"]
        code = attrs["code"]

        user = User.objects.filter(phone_number=phone_number).first()

        if not user:
            raise serializers.ValidationError("کاربری با این شماره وجود ندارد.")

        otp = (
            OTPCode.objects.filter(
                phone_number=phone_number,
                is_used=False,
            )
            .order_by("-created_at")
            .first()
        )

        if otp is None:
            raise serializers.ValidationError("کد تاییدی برای این شماره وجود ندارد.")

        if otp.is_expired():
            raise serializers.ValidationError("کد تایید منقضی شده است.")

        if not check_password(code, otp.code):
            raise serializers.ValidationError("کد تایید اشتباه است.")

        otp.is_used = True
        otp.save(update_fields=["is_used"])

        attrs["user"] = user

        return attrs








class PublicInformationSerializer(serializers.ModelSerializer):
    children = serializers.SerializerMethodField()

    class Meta:
        model = Information
        fields = ("id", "title", "text", "file", "children")

    def get_children(self, obj):
        return PublicInformationSerializer(
            obj.children.all(), many=True, context=self.context
        ).data


class PublicStaffLineSerializer(serializers.Serializer):
    id = serializers.UUIDField(source="line.id")
    title = serializers.CharField(source="line.title")


class PublicStaffSerializer(serializers.ModelSerializer):
    first_name = serializers.CharField(source="user.first_name", read_only=True)
    last_name = serializers.CharField(source="user.last_name", read_only=True)
    avatar = serializers.ImageField(source="user.avatar", read_only=True)
    bio = serializers.CharField(source="user.bio", read_only=True)
    degree = serializers.CharField(source="user.degree", read_only=True)
    informations = serializers.SerializerMethodField()
    lines = serializers.SerializerMethodField()

    class Meta:
        model = Staff
        fields = (
            "id",
            "first_name",
            "last_name",
            "avatar",
            "position",
            "degree",
            "bio",
            "lines",
            "informations",
        )

    def get_informations(self, obj):
        # فقط ریشه‌ها؛ فرزندان داخل خود سریالایزر می‌آیند
        roots = [i for i in obj.user.informations.all() if i.parent_id is None]
        return PublicInformationSerializer(roots, many=True, context=self.context).data

    def get_lines(self, obj):
        memberships = obj.line_memberships.filter(
            line__parent__isnull=True
        ).select_related("line")

        return PublicStaffLineSerializer(
            memberships,
            many=True,
            context=self.context,
        ).data