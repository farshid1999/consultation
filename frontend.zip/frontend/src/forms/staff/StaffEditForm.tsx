"use client";

import {useRouter} from "next/navigation";
import {zodResolver} from "@hookform/resolvers/zod";
import {useForm, type Control} from "react-hook-form";
import {toast} from "sonner";
import {staffUpdateSchema, type StaffUpdateFormValues} from "@/schemas/staff";
import type {InformationFormValues} from "@/schemas/information";
import {useUpdateStaff} from "@/hooks/useStaff";
import {toApiDateString, fromApiDateString} from "@/lib/date";
import type {ApiError, InformationRead, StaffDetail, StaffUpdateInput} from "@/types";
import StaffFormFields from "./StaffFormFields";

function mapInformation(info: InformationRead): InformationFormValues {
    return {
        title: info.title,
        text: info.text ?? "",
        file: null,
        existing_file: info.file ?? null, // جدید
        children: info.children?.map(mapInformation) ?? [],
    };
}

function mapDetailToFormValues(staff: StaffDetail): StaffUpdateFormValues {
    const {user} = staff;
    return {
        employee_code: staff.employee_code,
        position: staff.position,
        hire_date: fromApiDateString(staff.hire_date),
        user: {
            username: user.username,
            national_id: user.national_id,
            password: "",
            phone_number: user.phone_number,
            first_name: user.first_name ?? "",
            last_name: user.last_name ?? "",
            email: user.email ?? "",
            land_line: user.land_line ?? "",
            is_student: user.is_student,
            degree: user.degree ?? "",
            job: user.job ?? "",
            sport_discipline: user.sport_discipline ?? "",
            professional_background: user.professional_background ?? "",
            referral_code: user.referral_code ?? "",
            address: user.address
                ? {
                    country: user.address.country,
                    province: user.address.province,
                    city: user.address.city,
                    street: user.address.street,
                    postal_code: user.address.postal_code,
                    description: user.address.description ?? "",
                }
                : undefined,
            club: user.club
                ? {
                    name: user.club.name,
                    address: {
                        country: user.club.address.country,
                        province: user.club.address.province,
                        city: user.club.address.city,
                        street: user.club.address.street,
                        postal_code: user.club.address.postal_code,
                        description: user.club.address.description ?? "",
                    },
                }
                : undefined,
            avatar: null,
            bio: user.bio ?? "",
            birth_date: fromApiDateString(user.birth_date),
            informations: user.informations.map(mapInformation),
        },
    };
}

function cleanInformations(items?: InformationFormValues[]): any[] {
    return (items ?? []).map((item) => ({
        title: item.title,
        text: item.text || undefined,
        file: item.file ?? undefined,
        existing_file: !item.file ? item.existing_file ?? undefined : undefined,
        children: item.children?.length ? cleanInformations(item.children) : undefined,
    }));
}

export default function StaffEditForm({staff}: { staff: StaffDetail }) {
    const router = useRouter();
    const updateStaff = useUpdateStaff(staff.id);

    const {
        control,
        handleSubmit,
        setError,
        formState: {errors, isSubmitting, dirtyFields},
    } = useForm<StaffUpdateFormValues>({
        resolver: zodResolver(staffUpdateSchema),
        defaultValues: mapDetailToFormValues(staff),
    });


    const onSubmit = async (values: StaffUpdateFormValues) => {
        console.log("informations in form:", values.user?.informations);
        const u = values.user;
        const orig = staff.user;
        const infoTouched = Boolean(dirtyFields.user?.informations);

        const payload: StaffUpdateInput = {
            employee_code: values.employee_code,
            position: values.position,
            hire_date: toApiDateString(values.hire_date ?? undefined),


            user: {
                username: u?.username !== orig.username ? u?.username : undefined,
                national_id: u?.national_id !== orig.national_id ? u?.national_id : undefined,
                phone_number: u?.phone_number !== orig.phone_number ? u?.phone_number : undefined,
                password: u?.password ? u.password : undefined,
                avatar: u?.avatar instanceof File ? u.avatar : undefined,
                first_name: values.user?.first_name || undefined,
                last_name: values.user?.last_name || undefined,
                email: values.user?.email || undefined,
                land_line: values.user?.land_line || undefined,
                is_student: values.user?.is_student,
                degree: values.user?.degree || undefined,
                job: values.user?.job || undefined,
                sport_discipline: values.user?.sport_discipline || undefined,
                professional_background: values.user?.professional_background || undefined,
                referral_code: values.user?.referral_code || undefined,
                address: values.user?.address,
                club: values.user?.club,
                bio: values.user?.bio || undefined,
                birth_date: toApiDateString(values.user?.birth_date ?? undefined) ?? undefined,
                informations: infoTouched
                    ? (cleanInformations(values.user?.informations) as never)
                    : undefined,
            },
        };

        try {
            await updateStaff.mutateAsync(payload);
            toast.success("تغییرات با موفقیت ذخیره شد.");
            router.back();
        } catch (err) {
            const apiError = err as ApiError;
            toast.error(apiError.message ?? "ذخیره‌ی تغییرات با خطا مواجه شد.");
            Object.entries(apiError.fieldErrors ?? {}).forEach(([field, messages]) => {
                setError(field as never, {type: "server", message: messages[0]});
            });
        }
    };

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="flex flex-col gap-6 rounded-3xl border border-white/5 bg-white/[0.02] p-6 backdrop-blur-sm md:p-8"
        >
            {/* نمایش تصویر فعلی پروفایل */}
            {staff.user.avatar && (
                <div className="flex items-center gap-4 rounded-xl border border-white/5 bg-white/[0.03] p-4">
                    {/* eslint-disable-next-lines @next/next/no-img-element */}
                    <img
                        src={staff.user.avatar}
                        alt={staff.user.username}
                        className="h-12 w-12 rounded-full object-cover ring-2 ring-white/5"
                    />
                    <p className="text-xs text-cream/50">
                        تصویر فعلی پروفایل — برای تغییر، در بخش «اطلاعات شخصی» تصویر جدید بارگذاری کنید.
                    </p>
                </div>
            )}

            {/* باکس هشدار با استایل تم تیره */}
            <div
                className="rounded-xl border border-gold/20 bg-gold/5 p-4 text-xs leading-relaxed text-gold/80 flex gap-3 items-start">
                <span className="shrink-0 mt-0.5 text-gold">⚠️</span>
                <p>
                    توجه: بخش «اطلاعات تکمیلی» در ویرایش به‌طور کامل جایگزین می‌شود. اگر برای موردی که قبلاً فایل داشته،
                    فایل
                    جدیدی انتخاب نکنید، فایل قبلی آن حذف خواهد شد.
                </p>
            </div>

            <StaffFormFields
                control={control as unknown as Control<any>}
                errors={errors}
                mode="edit"
                initialShowAddress={Boolean(staff.user.address)}
                initialShowClub={Boolean(staff.user.club)}
                currentAvatarUrl={staff.user.avatar}
            />

            {/* دکمه‌های عملیات */}
            <div className="flex items-center justify-end gap-3 border-t border-white/5 pt-6 mt-4">
                <button
                    type="button"
                    onClick={() => router.back()}
                    className="rounded-xl border border-cream/10 bg-cream/5 px-6 py-3 text-sm font-medium text-cream/60 transition-all hover:border-cream/20 hover:bg-cream/10 hover:text-cream focus:outline-none"
                >
                    انصراف
                </button>
                <button
                    type="submit"
                    disabled={isSubmitting}
                    className="rounded-xl bg-gold px-8 py-3 text-sm font-bold text-deep shadow-lg shadow-gold/10 transition-all hover:bg-gold/90 hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
                >
                    {isSubmitting ? (
                        <span className="flex items-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-deep/30 border-t-deep"></span>
              در حال ذخیره...
            </span>
                    ) : (
                        "ذخیره‌ی تغییرات"
                    )}
                </button>
            </div>
        </form>
    );
}
